<!--start: Header -->
	<header>
		
		<!--start: Container -->
		<div class="container">
			
			<!--start: Row -->
			<div class="row">
					
				<!--start: Logo -->
				<div class="logo span3">
						
					<a class="brand" href="index.php"><img src="img/logoegyd.png" alt="Logo"></a>
						
				</div>
				<!--end: Logo -->
					
				<!--start: Navigation -->
				<div class="span9">
					
					<div class="navbar navbar-inverse">
			    		<div class="navbar-inner">
			          		<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
			            		<span class="icon-bar"></span>
			            		<span class="icon-bar"></span>
			            		<span class="icon-bar"></span>
			          		</a>
			          		<div class="nav-collapse collapse">
			            		<ul class="nav">
			              			<li class="active"><a href="index.php">Home</a></li>
                                    <li class="dropdown">
			                			<a href="#" class="dropdown-toggle" data-toggle="dropdown">Product <b class="caret"></b></a>
			                			<ul class="dropdown-menu">
			                  				<li><a href="#">PC Rakitan</a></li>
			                  				<li><a href="#">Printer</a></li>
			                  				<li><a href="#">Laptop</a></li>
			                  				<li><a href="#">Aksesoris</a></li>
			                  				<li><a href="#">CCTV</a></li>
			                  				<li><a href="#">SERVICE</a></li>
			                			</ul>
			              			</li>	            
									<li><a href="customer/testimoni.php">Testimonial</a></li>
                                    <!-- <li><a href="detail.php">Cart</a></li>-->
                                    <li><a href="cek_servisan1.php">Cek Servisan</a></li>
                                    <li><a href="profil.php">About Us</a></li>
			              			<li class="dropdown">
			                			<a href="#" class="dropdown-toggle" data-toggle="dropdown">Login <b class="caret"></b></a>
			                			<ul class="dropdown-menu">
			                  				<li><a href="login.html"> Login</a></li>
			                  				<li><a href="index.html">User Login</a></li>			       
			                			</ul>
			              			</li>

			            		</ul>
			          		</div>
			        	</div>
			      	</div>
					
				</div>	
				<!--end: Navigation -->
					
			</div>
			<!--end: Row -->
			
		</div>
		<!--end: Container-->			
			
	</header>
	<!--end: Header-->