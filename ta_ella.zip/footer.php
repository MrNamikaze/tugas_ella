<!-- start: Footer -->
	<div id="footer">
		
		<!-- start: Container -->
		<div class="container">
			
			<!-- start: Row -->
			<div class="row">

				<!-- start: About -->
				<div class="span3">
					
					<h3>Toko EGYD KOMPUTER</h3>
					<p>
					 Kami hadir untuk mempermudah para pelanggan tercinta untuk berbelanja di toko kami. kami menyediakan berbagai jenis Laptop, PC Build up, PC All in ONe, PC Rakitan, Printer, Projector, Finger Print, dan lainnya. selain yang baru kami menyediakan yang bekas nya juga loh	
                    </p>
						
				</div>
				<!-- end: About -->

				<!-- start: Photo Stream -->
				<div class="span3">
					
					<h3>Alamat Kami</h3>
                   Jl. Moh. Toha No.11, Kasturi, Kec. Kramatmulya, Kabupaten Kuningan, Jawa Barat 45521
                    Website : <a href="http://www.laptopmurahkuningan.com" target="_blank">www.laptopmurahkuningan.com</a>
                    </div>

				<!-- end: Photo Stream -->
				<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                     <div class="span3">
                    

                        <h3> Check Status Service</h3>
                        <div class="row">
                           <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                              <input type="text" class="form-control" id="key" placeholder="Nomor Nota / S.N." aria-describedby="basic-addon1" name="check" style="font-weight: bold;">
                           </div>
                           
                        </div>
                       <a href=""><button  id="mybutton"   class="userinfo btn btn-success">Check</button></a> 
                       
                     </div>
                  </div>

				<div class="span3">
				
					<!-- start: Follow Us -->
					<h3>Follow Us!</h3>
					<ul class="social-grid">
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-twitter">
											<a href="http://twitter.com"></a>
										</div>
										<div class="social-info-back social-twitter-hover">
											<a href="http://twitter.com"></a>
										</div>	
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-linkedin">
											<a href="http://facebook.com"></a>
										</div>
										<div class="social-info-back social-linkedin-hover">
											
											<a href="http://facebook.com"></a>
										</div>
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-dribbble">
											<a href="http://dribble.com"></a>
										</div>
										<div class="social-info-back social-dribble-hover">
											<a href="http://dribble.com"></a>
										</div>	
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-flickr">
											<a href="http://flickr.com"></a>
										</div>
										<div class="social-info-back social-flickr-hover">
											<a href="http://flickr.com"></a>
										</div>	
									</div>
								</div>
							</div>
						</li>
					</ul>
					<!-- end: Follow Us -->
				
					<!-- start: Newsletter -->
				<!--	<form id="newsletter">
						<h3>Newsletter</h3>
						<p>Please leave us your email</p>
						<label for="newsletter_input">@:</label>
						<input type="text" id="newsletter_input"/>
						<input type="submit" id="newsletter_submit" value="submit">
					</form> -->
					<!-- end: Newsletter -->
				
				</div>
				
			</div>
			<!-- end: Row -->	
			
		</div>
		<!-- end: Container  -->

	</div>
	<!-- end: Footer -->

	<!-- start: Copyright -->
	<div id="copyright">
	
		<!-- start: Container -->
		<div class="container">
		
			<p>
				Copyright &copy; <a href="http://bootstrapmaster.com" alt="Bootstrap Themes">Ela Laela Turohmah &copy; 2022 </a> 
	
		</div>
		<!-- end: Container  -->
		
	</div>	
	<!-- end: Copyright -->